# token-audit MCP Server

Model Context Protocol server that exposes design token auditing capabilities as programmatic API calls.

## Installation

```bash
npm i -g token-audit-mcp
```

Optional dependencies (automatically used if installed):
- `playwright-core` - Browser-based runtime measurement
- `style-dictionary` - Export to Style Dictionary format

## Quick Start

### With Qoder MCP Registration

Register in your Qoder settings:

```json
{
  "serverId": "token-audit-mcp",
  "name": "token-audit",
  "command": "/usr/local/bin/node",
  "args": ["/usr/local/lib/node_modules/token-audit-mcp/src/mcp-server.js"],
  "timeout": 120000
}
```

### Direct CLI Usage

```bash
# Start MCP server
token-audit-mcp

# Or run via npx
npx token-audit-mcp
```

## Available Tools

### Core Audit Tools (6)

| Tool | Description |
|------|-------------|
| `audit_run` | Trigger async audit on local path or URL |
| `audit_findings` | Query findings with filters |
| `audit_summary` | Get quick statistics |
| `audit_html_report` | Download HTML report |
| `audit_json` | Download JSON artifact |
| `job_status` | Poll job progress |

### Export Tools (5)

| Tool | Format | Use Case |
|------|--------|----------|
| `export_tokens_studio` | Tokens Studio/Figma | Design team collaboration |
| `export_style_dictionary` | SD Web/iOS/Android | Multi-platform apps |
| `export_dtcg` | W3C DTCG spec | Standardized exchange |
| `export_tailwind` | Tailwind config | CSS utility framework |
| `export_shadcn` | shadcn/ui variables | Component library theming |

### Semantic Recommendations (3)

| Tool | Purpose |
|------|---------|
| `audit_recommendations` | Multi-rule suggestions |
| `recommend_orphan_merge` | Unused token merges |
| `recommend_alias_optimization` | Simplify alias chains |

### Diagnostic Tools (2)

| Tool | Purpose |
|------|---------|
| `list_jobs` | Browse cached audits |
| `delete_job` | Remove old jobs |

## Example Workflow

```javascript
// 1. Run audit on project
const result = await mcp.call('audit_run', {
  target: './src',
  ignore: ['node_modules', 'pristine'],
  severity: 'error'
});
// Returns: { jobId: 'uuid', status: 'running' }

// 2. Poll completion
await sleep(2000);
const status = await mcp.call('job_status', { jobId: result.jobId });
// Returns: { status: 'complete', progress: 100 }

// 3. Query critical issues
const errors = await mcp.call('audit_findings', {
  jobId: result.jobId,
  severity: 'error'
});
// Returns: { findings: [...], total: 5 }

// 4. Export for designers
await mcp.call('export_tokens_studio', { jobId: result.jobId });
// Returns: { filePath: '/path/to/tokens-studio.json' }

// 5. Export for frontend devs
await mcp.call('export_tailwind', { 
  jobId: result.jobId, 
  themePrefix: 'nm-' 
});
// Returns: Tailwind config file path
```

## Job Lifecycle

1. **Create**: `audit_run()` generates deterministic job ID from target+ignore
2. **Run**: Background process scans sources + measures runtime
3. **Complete**: Results stored in `.token-audit-cache/<jobId>/`
4. **Query**: All tools read from cache (no re-scan needed)
5. **Cleanup**: Automatic 30-day TTL or manual `delete_job()`

## Caching Strategy

Jobs persisted in `.token-audit-cache/<jobId>/`:

```
.jobId/
├── meta.json           # Metadata object
├── report.json         # Full audit JSON
├── report.html         # Self-rendered report
└── exports/            # All export formats
    ├── tokens-studio.json
    ├── style-dictionary/
    ├── dtcg.json
    ├── tailwind.config.js
    └── shadcn-theme.css
```

Same target+ignore → same job ID (prevents duplicate scans).

## Graceful Degradation

| Missing Dependency | Behavior |
|--------------------|----------|
| No Playwright | Skip runtime measurement, report notes it |
| No dembrandt | Skip classification, static analysis still works |
| Target unreachable | Exit immediately with error message |
| No source files | Complete with empty results |

## Error Handling

All tools return structured errors:

```typescript
{
  success: false,
  error: {
    code: "NETWORK_ERROR",
    message: "Target URL unreachable after 30s",
    details: { target: "https://broken.example" }
  }
}
```

## Performance

Typical audit times:
- Small SPA (1-2 pages): ~5-10 seconds
- Medium app (3-5 docs): ~15-20 seconds  
- Large site (10+ docs): ~30-45 seconds

Long-running audits handled via async job pattern (no blocking).

## Development

```bash
# Install dev dependencies
npm install

# Run tests
npm test

# Start dev server with hot reload
npm run dev
```

## License

MIT
