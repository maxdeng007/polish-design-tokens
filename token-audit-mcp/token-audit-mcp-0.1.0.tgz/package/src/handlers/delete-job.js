import { rm } from 'node:fs/promises';
import { join } from 'node:path';

/**
 * Permanently remove a job and all its artifacts.
 * 
 * @param {object} params - Tool parameters
 * @param {string} params.jobId - Job UUID
 * @param {object} deps - Dependencies
 * @param {object} deps.store - JobStore
 * @returns {Promise<{deleted: boolean, freed_bytes: number, artifacts_removed: string[]}>}
 */
export async function delete_job(params, deps) {
  const { jobId } = params;
  
  const result = await deps.store.delete(jobId);
  
  if (!result.deleted) {
    throw new Error(`Job ${jobId} not found`);
  }
  
  return {
    deleted: true,
    freed_bytes: result.freed_bytes,
    artifacts_removed: [
      join('.token-audit-cache', jobId, 'meta.json'),
      join('.token-audit-cache', jobId, 'report.json'),
      join('.token-audit-cache', jobId, 'declarations.json'),
      join('.token-audit-cache', jobId, 'exports')
    ]
  };
}
